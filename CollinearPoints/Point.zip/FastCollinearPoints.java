/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import java.util.Arrays;
import java.util.Comparator;

public class FastCollinearPoints {
    private LineSegment[] lineSegList;
    private int segmentNumber = 0;

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        LineSegment[] lines = new LineSegment[points.length / 4 + 1];
        for (int i = 0; i < points.length; i += 1) {
            if (points[i] == null) {
                throw new IllegalArgumentException("The point should NOT be null!");
            }
            Point[] orderedPointList = makeSlopeInOrder(points, i);
            for (int p = 0; p < orderedPointList.length - 3; p += 1) {
                if (orderedPointList[p + 1].slopeTo(orderedPointList[p]) == Double.NEGATIVE_INFINITY
                        || orderedPointList[p + 2].slopeTo(orderedPointList[p])
                        == Double.NEGATIVE_INFINITY
                        || orderedPointList[p + 3].slopeTo(orderedPointList[p])
                        == Double.NEGATIVE_INFINITY) {
                    throw new IllegalArgumentException(
                            "There should NOT have two identical points!");
                }
                if (orderedPointList[p + 1].slopeTo(orderedPointList[p]) == orderedPointList[p
                        + 2].slopeTo(orderedPointList[p])
                        && orderedPointList[p + 3].slopeTo(orderedPointList[p]) == orderedPointList[
                        p + 2].slopeTo(orderedPointList[p])) {
                    lines[segmentNumber] = lsGenerator(orderedPointList[p],
                                                       orderedPointList[p + 1],
                                                       orderedPointList[p + 2],
                                                       orderedPointList[p + 3]);
                    segmentNumber += 1;
                }
            }
        }
        lineSegList = new LineSegment[segmentNumber];
        System.arraycopy(lines, 0, lineSegList, 0, segmentNumber);
    }

    private Point[] makeSlopeInOrder(Point[] pointList, int index) {
        Point[] points = new Point[pointList.length - 1];
        System.arraycopy(pointList, 0, points, 0, index);
        if (index < pointList.length - 1) {
            System.arraycopy(pointList, index + 1, points, index, pointList.length - index - 1);
        }
        Comparator<Point> c = pointList[index].slopeOrder();
        Arrays.sort(points, c);
        return points;
    }

    private LineSegment lsGenerator(Point a, Point b, Point c, Point d) {
        Point[] pList = new Point[] { a, b, c, d };
        Point max = a;
        Point min = a;
        for (int i = 1; i < 4; i += 1) {
            if (pList[i].compareTo(max) > 0) {
                max = pList[i];
            }
            if (pList[i].compareTo(min) < 0) {
                min = pList[i];
            }
        }
        return new LineSegment(max, min);
    }

    public int numberOfSegments() {
        return segmentNumber;
    }

    public LineSegment[] segments() {
        return lineSegList;
    }

    public static void main(String[] args) {


    }
}
